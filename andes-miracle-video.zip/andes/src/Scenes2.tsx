import React from 'react';
import {Svg, Sky, Clouds, Peaks, FAR, NEAR, Ground, Snow, Fuselage, Vignette, Plane, Heli, IcoQ, IcoAlert, IcoCan, IcoGlobe, IcoScale, IcoNote, IcoHeart, IcoPerson, IcoFlame, IcoMount, IcoLink, IcoCal, IcoRadio, IcoWarn} from './Art';
import {Char, LOOKS, CROWD} from './Character';
import {Card, IconAt, Pill, Stamp, Thought, Shake, BigText, Wrap} from './UI';
import {clamp, vis, pop, popOut, lerp, ease, useT} from './util';
import {INK} from './theme';

const crowdXs = [300, 560, 820, 1080, 1340, 1620];

/* ৮: হাল ছাড়লেন না + কঠিন সিদ্ধান্ত (প্রতীকীভাবে, মৃদু আলোয়) */
export const S8: React.FC = () => {
  const S = 95.2, t = useT(S);
  const early = t < 97;
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Fuselage t={t} />
        {crowdXs.map((x, i) => (
          <Char key={i} look={CROWD[i]} x={x} y={1000} scale={1.35} t={t} seed={i} pose={early ? 'hold' : 'cover'} mood={early ? 'determined' : 'sad'} flip={!early && i % 2 === 1} shake={early ? 0 : 0.8} />
        ))}
        <rect x={-10} y={-10} width={1940} height={1100} fill="#0a1830" opacity={early ? 0.1 : clamp(t, 97, 100, 0.1, 0.55)} />
        <Vignette op={0.6} />
      </Svg>
      <Thought x={960} y={200} tx={960} ty={470} p={popOut(t, 97.0, 100.2)}><svg width={130} height={130} viewBox="-50 -50 100 100"><IcoCan /></svg></Thought>
      <Thought x={960} y={200} tx={960} ty={470} p={popOut(t, 111.6, 115.1)}><svg width={150} height={150} viewBox="-50 -50 100 100"><IcoScale t={t} /></svg></Thought>
    </Wrap>
  );
};

/* ৯: তুষারধস */
export const S9: React.FC = () => {
  const S = 115.2, t = useT(S);
  const av = clamp(t, 119.2, 122.4);
  const mound = clamp(t, 121.8, 123);
  return (
    <Wrap S={S} t={t}>
      <Shake amp={t > 119.2 && t < 123 ? 12 : 0} t={t}>
        <Svg>
          <Fuselage t={t} />
          {crowdXs.map((x, i) => (
            <Char key={i} look={CROWD[i]} x={x} y={1000} scale={1.35} t={t} seed={i} pose={t > 124.8 ? 'stand' : 'cover'} mood={t < 119 ? 'tired' : t < 124.8 ? 'scared' : 'neutral'} shake={t > 119 && t < 124.8 ? 2 : 0} opacity={t > 123 && (i === 4 || i === 5) && t < 124.8 ? 0.35 : 1} />
          ))}
          <path d={`M ${lerp(2100, -300, av)} -20 L ${lerp(2300, -100, av)} -20 L ${lerp(2300, -100, av)} 1100 L ${lerp(1900, -400, av)} 1100 Q ${lerp(2000, -300, av)} 800 ${lerp(1860, -420, av)} 500 Q ${lerp(2000, -300, av)} 200 ${lerp(2100, -300, av)} -20Z`} fill="#fff" stroke={INK} strokeWidth={4} opacity={t < 122.6 ? 1 : 0} />
          <Snow t={t} n={120} speed={700} wind={-1200} />
          <path d={`M 1300 1100 Q 1500 ${1100 - 340 * mound} 1930 ${1100 - 420 * mound} L 1930 1100Z`} fill="#fff" stroke={INK} strokeWidth={4} />
          <rect x={-10} y={-10} width={1940} height={1100} fill="#ffe9a8" opacity={0.28 * clamp(t, 124.8, 126.5)} />
          <Vignette op={0.45} />
        </Svg>
      </Shake>
      <Stamp x={960} y={240} p={popOut(t, 117.1, 120)} size={120} color="#e04848">দিন ১৭</Stamp>
      <Stamp x={960} y={300} p={popOut(t, 123, 124.8)} size={140} color="#e04848">−৮ জন</Stamp>
      <IconAt x={960} y={150} size={200} p={popOut(t, 124.9, 127.4) * (1 + 0.08 * Math.sin(t * 6))}><IcoHeart /></IconAt>
    </Wrap>
  );
};

/* ১০: সময় গড়ানো, ১২ ডিসেম্বর, তিনজনের যাত্রা */
export const S10: React.FC = () => {
  const S = 127.5, t = useT(S);
  const mg = t < 130.8;
  const walk = clamp(t, 142.7, 145.4);
  return (
    <Wrap S={S} t={t}>
      {mg ? (
        <>
          <Svg><Sky a="#0e1a33" b="#27467c" id="s10a" /><Vignette op={0.6} /></Svg>
          <Card x={420} y={500} p={pop(t, 127.6)} size={90} bg="#ffe9a8">দিন</Card>
          <Card x={960} y={500} p={pop(t, 128.4)} size={90} bg="#bfe3fa">সপ্তাহ</Card>
          <Card x={1500} y={500} p={pop(t, 129.7)} size={90} bg="#ffb4b4">মাস</Card>
          <BigText x={690} y={500} op={pop(t, 128.0)} size={110}>→</BigText>
          <BigText x={1230} y={500} op={pop(t, 129.3)} size={110}>→</BigText>
          <IconAt x={960} y={220} size={190} p={vis(t, 127.5, 130.8)} rot={Math.sin(t * 6) * 8}><IcoCal label={`${Math.floor(1 + clamp(t, 127.5, 130.8) * 9)}`} /></IconAt>
        </>
      ) : (
        <>
          <Svg>
            <Sky a="#8da2b8" b="#e1ecf6" id="s10b" />
            <Peaks pts={FAR} color="#8ea3ba" dy={40} />
            <Peaks pts={NEAR} color="#b7c9db" dy={100} />
            <Ground y={850} />
            {t < 136.7 ? [0, 1, 2, 3].map((i) => (
              <Char key={i} look={CROWD[i]} x={560 + i * 220} y={960} scale={1.4} t={t} seed={i} mood={t > 134.7 ? 'determined' : 'sad'} pose="stand" flip tear={i === 1 && t < 134.7} />
            )) : (
              <>
                <Char look={LOOKS.parado} x={lerp(700, 1500, walk)} y={960} scale={1.5} t={t} mood="determined" pose={walk > 0 ? 'walk' : 'stand'} />
                <Char look={LOOKS.canessa} x={lerp(960, 1760, walk)} y={960} scale={1.5} t={t} mood="determined" pose={walk > 0 ? 'walk' : 'stand'} seed={2} />
                <Char look={LOOKS.vizintin} x={lerp(1220, 2020, walk)} y={960} scale={1.5} t={t} mood="determined" pose={walk > 0 ? 'walk' : 'stand'} seed={4} />
              </>
            )}
            <Snow t={t} n={60} />
          </Svg>
          <Thought x={900} y={200} tx={900} ty={430} p={popOut(t, 130.9, 134.6)}><svg width={130} height={130} viewBox="-50 -50 100 100"><IcoQ /></svg></Thought>
          <Pill y={60} op={vis(t, 136.7, 141)}>১২ ডিসেম্বর</Pill>
          <Pill x={700 + 800 * walk} y={360} op={vis(t, 138.4, 145) * (1 - walk)} bg="#7aa7ff">ফার্নান্দো পারাদো</Pill>
          <Pill x={960 + 800 * walk} y={300} op={vis(t, 140.0, 145) * (1 - walk)} bg="#ff9c9c">রবার্তো ক্যানেসা</Pill>
          <Pill x={1220 + 800 * walk} y={250} op={vis(t, 141.3, 145) * (1 - walk)} bg="#8fe3a0">আন্তোনিও ভিসিনতিন</Pill>
        </>
      )}
    </Wrap>
  );
};

/* ১১: পাহাড়ি পথ, ভিসিনতিনের ফেরা, কাতালানের সাক্ষাৎ */
export const S11: React.FC = () => {
  const S = 145.4, t = useT(S);
  const trek = t < 155.6;
  const vizBack = clamp(t, 150.8, 153.4);
  return (
    <Wrap S={S} t={t}>
      <Shake amp={t < 150.8 ? 2 : 0} t={t}>
        <Svg>
          <Sky a={trek ? '#9aaec2' : '#a9d4f2'} b={trek ? '#dfe9f3' : '#eaf6ff'} id="s11" />
          <Peaks pts={FAR} color="#8ea3ba" dx={-(t * 14) % 300} dy={30} />
          <Peaks pts={NEAR} color={trek ? '#b7c9db' : '#9cc3a0'} dx={-(t * 30) % 300} dy={110} />
          <Ground y={860} color={trek ? '#f4f9fd' : '#e9f2dc'} />
          {trek ? (
            <>
              <Char look={LOOKS.parado} x={1000} y={970} scale={1.5} t={t} mood="tired" pose="walk" />
              <Char look={LOOKS.canessa} x={1250} y={970} scale={1.5} t={t} mood="determined" pose="walk" seed={2} />
              {vizBack < 1 && <Char look={LOOKS.vizintin} x={lerp(770, 200, vizBack)} y={970} scale={1.5} t={t} mood="sad" pose={vizBack > 0 ? 'wave' : 'walk'} seed={4} flip={vizBack > 0.05} opacity={1 - clamp(vizBack, 0.8, 1)} />}
              <Snow t={t} n={120} speed={300} wind={350} />
            </>
          ) : (
            <>
              <path d="M 880 700 L 1040 700 L 1130 1100 L 840 1100Z" fill="#6fb6ee" stroke={INK} strokeWidth={4} />
              {[0, 1, 2].map((i) => <path key={i} d={`M ${900 + i * 20} ${760 + i * 120} q 40 -20 80 0`} fill="none" stroke="#fff" strokeWidth={5} />)}
              <Char look={LOOKS.parado} x={460} y={980} scale={1.5} t={t} mood={t > 159 ? 'happy' : 'tired'} pose={t > 159 ? 'up' : 'walk'} />
              <Char look={LOOKS.canessa} x={680} y={990} scale={1.5} t={t} mood={t > 159 ? 'happy' : 'tired'} pose={t > 167.9 ? 'point' : t > 159 ? 'up' : 'walk'} seed={2} />
              <Char look={LOOKS.catalan} x={1560} y={960} scale={1.4} t={t} mood="surprised" pose="wave" seed={5} flip opacity={clamp(t, 160.3, 161.2)} />
            </>
          )}
        </Svg>
      </Shake>
      <Pill y={60} op={vis(t, 155.6, 160)}>২০ ডিসেম্বর</Pill>
      <Pill x={1560} y={250} op={vis(t, 164.1, 170)} bg="#ffe08a">সার্জিও কাতালান</Pill>
      <IconAt x={lerp(760, 1440, ease(clamp(t, 167.9, 170)))} y={lerp(560, 480, clamp(t, 167.9, 170)) - Math.sin(clamp(t, 167.9, 170) * 3.14 / 1.0) * 60} size={150} p={t > 167.9 && t < 170.1 ? 1 : 0} rot={Math.sin(t * 8) * 18}><IcoNote /></IconAt>
      <Thought x={1560} y={200} tx={1560} ty={430} p={popOut(t, 170.1, 171.9)}><svg width={150} height={150} viewBox="-50 -50 100 100"><IcoRadio t={t} /></svg></Thought>
    </Wrap>
  );
};

/* ১২: হেলিকপ্টার উদ্ধার */
export const S12: React.FC = () => {
  const S = 171.9, t = useT(S);
  const land = ease(clamp(t, 172.4, 176.8));
  const walk = clamp(t, 177.5, 181);
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Sky a="#9fd0f4" b="#eaf6ff" id="s12" />
        <Peaks pts={FAR} color="#8ea3ba" dy={40} />
        <Peaks pts={NEAR} color="#b7c9db" dy={100} />
        <Ground y={850} />
        <Plane x={330} y={900} s={0.85} rot={-3} t={t} hideTail hideWing />
        <Heli x={lerp(2350, 1450, land)} y={lerp(260, 760, land)} s={1.1} t={t} />
        {[0, 1, 2, 3].map((i) => (
          <Char key={i} look={CROWD[i]} x={lerp(720 + i * 170, 1250 + i * 40, walk * (i < 3 ? 1 : 0.5))} y={960} scale={1.3} t={t} seed={i} mood="happy" pose={walk > 0 && walk < 1 ? 'walk' : 'up'} opacity={t > 182.4 ? clamp(t, 182.4, 183.6, 1, 0.3) : 1} />
        ))}
        {t > 180 && [0, 1, 2].map((i) => <Char key={'n' + i} look={CROWD[(i + 3) % 6]} x={lerp(640 + i * 150, 1330 + i * 40, clamp(t, 180, 183.4))} y={990} scale={1.2} t={t} seed={i + 9} mood="happy" pose="walk" />)}
        <Snow t={t} n={70} speed={200} wind={300} />
      </Svg>
      <Pill y={60} op={vis(t, 172.4, 176.5)}>২২ ডিসেম্বর, ১৯৭২</Pill>
      <Pill y={60} op={vis(t, 180, 183.7)}>২৩ ডিসেম্বর</Pill>
    </Wrap>
  );
};

/* ১৩: ১৬/৪৫, ৭২ দিন, হারানো ও আশা, মিরাকল অব দ্য আন্দিজ */
export const S13: React.FC = () => {
  const S = 183.7, t = useT(S);
  const grid = t < 188.3;
  const day = Math.round(clamp(t, 188.2, 193.5, 1, 72));
  const faint = [
    {c: '#9aa7b8', x: 600}, {c: '#9aa7b8', x: 960}, {c: '#9aa7b8', x: 1320},
  ];
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Sky a={t > 198.9 ? '#16294f' : '#0e1a33'} b={t > 198.9 ? '#e0894a' : '#27467c'} id="s13" />
        {t > 198.9 && <circle cx={960} cy={760} r={140 + 20 * Math.sin(t * 3)} fill="#ffd27a" opacity={0.7 * clamp(t, 198.9, 201.5)} />}
        {t > 198.9 && <Peaks pts={NEAR} color="#1d2d4f" snow="#f4d9b0" dy={160} />}
        {grid && [...Array(45)].map((_, i) => {
          const cx = 360 + (i % 9) * 150, cy = 400 + Math.floor(i / 9) * 125;
          const alive = i < 16;
          const lit = alive ? clamp(t, 185.4 + i * 0.04, 186.2) : 0;
          return <g key={i} transform={`translate(${cx} ${cy}) scale(${pop(t, 183.9 + i * 0.02) * 1.15})`}><IcoPerson c={lit > 0.5 ? '#5ee08a' : '#5b6578'} /></g>;
        })}
        {t >= 194.3 && t < 198.9 && faint.map((f, i) => <g key={i} opacity={clamp(t, 194.3 + i * 0.7, 198.8, 1, 0)} transform={`translate(${f.x} ${540 - (t - 194.3) * 14}) scale(2.6)`}><IcoPerson c={f.c} /></g>)}
        <Vignette op={0.5} />
      </Svg>
      {grid && <Card x={960} y={150} p={popOut(t, 185.3, 188.3)} size={96} bg="#5ee08a">মাত্র ১৬ জন জীবিত</Card>}
      {t >= 188.2 && t < 194.3 && (
        <>
          <BigText y={420} op={vis(t, 188.2, 194.3)} size={360} color="#ffd23f">{`${day}`.replace(/[0-9]/g, (d) => '০১২৩৪৫৬৭৮৯'[+d])}</BigText>
          <BigText y={700} op={vis(t, 188.6, 194.3)} size={130}>দিন বরফের পাহাড়ে</BigText>
          <div style={{position: 'absolute', left: 360, top: 880, width: 1200, height: 36, borderRadius: 18, background: '#1b2a44', border: `5px solid ${INK}`, opacity: vis(t, 188.4, 194.3)}}>
            <div style={{width: `${(day / 72) * 100}%`, height: '100%', borderRadius: 14, background: '#ffd23f'}} />
          </div>
        </>
      )}
      <IconAt x={960} y={250} size={230} p={popOut(t, 199.2, 202) * (1 + 0.1 * Math.sin(t * 7))}><IcoHeart /></IconAt>
      <Card x={960} y={500} p={popOut(t, 202, 205.8)} size={100} bg="#ffd23f">মিরাকল অব দ্য আন্দিজ</Card>
      <div style={{position: 'absolute', left: 960, top: 360, transform: 'translate(-50%,-50%)', opacity: vis(t, 202.2, 205.8), width: 150, height: 150}}><svg viewBox="-50 -50 100 100"><IcoMount /></svg></div>
    </Wrap>
  );
};

/* ১৪: শেষ শিক্ষা */
export const S14: React.FC = () => {
  const S = 208.9, t = useT(S);
  const items: [number, React.ReactNode, string, string][] = [
    [209.9, <IcoFlame />, 'ইচ্ছাশক্তি', '#ffe0b0'], [211.3, <IcoMount />, 'সাহস', '#cfe6ff'], [212.5, <IcoLink />, 'একে অপরকে আঁকড়ে ধরা', '#ffd0d0'],
  ];
  const dawn = clamp(t, 208.9, 222);
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Sky a={`rgb(${lerp(14, 60, dawn)},${lerp(26, 90, dawn)},${lerp(51, 150, dawn)})`} b={`rgb(${lerp(80, 255, dawn)},${lerp(70, 190, dawn)},${lerp(110, 120, dawn)})`} id="s14" />
        <circle cx={960} cy={lerp(900, 640, dawn)} r={170} fill="#fff1b8" opacity={0.85} />
        <Peaks pts={FAR} color="#2a3f6a" snow="#f6e2c4" dy={200} />
        <Peaks pts={NEAR} color="#1b2c52" snow="#f6e2c4" dy={260} />
        {t > 217.4 && <Char look={LOOKS.parado} x={1450} y={lerp(780, 770, 1)} scale={0.9} t={t} mood="happy" pose="up" opacity={clamp(t, 217.4, 218.4)} />}
        <Vignette op={0.35} />
      </Svg>
      {items.map(([at, ic, label, bg], i) => (
        <Card key={i} x={960} y={270 + i * 200} p={popOut(t, at, 217.3)} size={70} bg={bg}>
          <svg width={100} height={100} viewBox="-50 -50 100 100">{ic}</svg><span>{label}</span>
        </Card>
      ))}
      <Card x={960} y={420} p={popOut(t, 220.9, 224)} size={150} bg="#ffd23f" rot={-3}>হাল না ছাড়া!</Card>
    </Wrap>
  );
};
