import React from 'react';
import {fontFamily} from './font';
import {INK, GOLD} from './theme';
import {clamp} from './util';

/** Floating overlay icon holder (SVG icon centered at x,y) */
export const IconAt: React.FC<{x: number; y: number; size?: number; p?: number; rot?: number; children: React.ReactNode}> = ({x, y, size = 140, p = 1, rot = 0, children}) => (
  <div style={{position: 'absolute', left: x - size / 2, top: y - size / 2, width: size, height: size, transform: `scale(${p}) rotate(${rot}deg)`, opacity: Math.min(1, p * 2)}}>
    <svg width={size} height={size} viewBox="-50 -50 100 100">{children}</svg>
  </div>
);

/** Thought bubble with trailing circles toward (tx,ty) */
export const Thought: React.FC<{x: number; y: number; w?: number; h?: number; tx: number; ty: number; p: number; children?: React.ReactNode}> = ({x, y, w = 220, h = 170, tx, ty, p, children}) => {
  const sx = x, sy = y + h / 2;
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: 1920, height: 1080, pointerEvents: 'none', opacity: Math.min(1, p * 2)}}>
      {[0.2, 0.45, 0.7].map((u, i) => {
        const r = [22, 15, 10][i];
        return <div key={i} style={{position: 'absolute', left: sx + (tx - sx) * u - r, top: sy + (ty - sy) * u - r, width: r * 2, height: r * 2, borderRadius: '50%', background: '#fff', border: `4px solid ${INK}`, transform: `scale(${p})`}} />;
      })}
      <div style={{position: 'absolute', left: x - w / 2, top: y - h / 2, width: w, height: h, borderRadius: '50%', background: '#fff', border: `6px solid ${INK}`, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${p})`, boxShadow: '0 8px 0 rgba(0,0,0,0.12)'}}>{children}</div>
    </div>
  );
};

export const Card: React.FC<{x: number; y: number; w?: number; p?: number; bg?: string; color?: string; size?: number; children: React.ReactNode; rot?: number}> = ({x, y, w, p = 1, bg = '#ffffff', color = INK, size = 56, children, rot = 0}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, transform: `translate(-50%,-50%) scale(${p}) rotate(${rot}deg)`, opacity: Math.min(1, p * 2), background: bg, color, border: `6px solid ${INK}`, borderRadius: 28, padding: '18px 34px', fontFamily, fontWeight: 700, fontSize: size, textAlign: 'center', boxShadow: '0 10px 0 rgba(0,0,0,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 20, whiteSpace: 'nowrap'}}>{children}</div>
);

export const Pill: React.FC<{x?: number; y: number; op: number; bg?: string; color?: string; size?: number; children: React.ReactNode}> = ({x = 960, y, op, bg = GOLD, color = INK, size = 46, children}) => (
  <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%, ${(1 - op) * -30}px)`, opacity: op, background: bg, color, border: `5px solid ${INK}`, borderRadius: 60, padding: '8px 34px', fontFamily, fontWeight: 700, fontSize: size, whiteSpace: 'nowrap', boxShadow: '0 6px 0 rgba(0,0,0,0.2)'}}>{children}</div>
);

export const Stamp: React.FC<{x: number; y: number; p: number; color?: string; size?: number; rot?: number; children: React.ReactNode}> = ({x, y, p, color = '#e04848', size = 110, rot = -6, children}) => (
  <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${1 + (1 - Math.min(p, 1)) * 1.2}) rotate(${rot}deg)`, opacity: Math.min(1, p * 2), color, border: `12px solid ${color}`, borderRadius: 24, padding: '6px 44px', fontFamily, fontWeight: 700, fontSize: size, background: 'rgba(255,255,255,0.92)', whiteSpace: 'nowrap', letterSpacing: 2}}>{children}</div>
);

export const BigText: React.FC<{x?: number; y: number; op: number; size?: number; color?: string; children: React.ReactNode}> = ({x = 960, y, op, size = 120, color = '#fff', children}) => (
  <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${0.85 + 0.15 * op})`, opacity: op, color, fontFamily, fontWeight: 700, fontSize: size, textAlign: 'center', whiteSpace: 'nowrap', WebkitTextStroke: `10px ${INK}`, paintOrder: 'stroke fill'}}>{children}</div>
);

export const Shake: React.FC<{amp: number; t: number; children: React.ReactNode}> = ({amp, t, children}) => (
  <div style={{position: 'absolute', inset: 0, transform: amp ? `translate(${Math.sin(t * 90) * amp}px, ${Math.cos(t * 77) * amp}px)` : undefined}}>{children}</div>
);

export const Flash: React.FC<{t: number; a: number; d?: number}> = ({t, a, d = 0.35}) => (
  <div style={{position: 'absolute', inset: 0, background: '#fff', opacity: t < a ? 0 : clamp(t, a, a + d, 1, 0)}} />
);

/** Scene wrapper: quick fade/zoom-in at scene start */
export const Wrap: React.FC<{S: number; t: number; children: React.ReactNode}> = ({S, t, children}) => (
  <div style={{position: 'absolute', inset: 0, overflow: 'hidden', opacity: clamp(t, S, S + 0.15), transform: `scale(${1 + 0.04 * clamp(t, S, S + 0.6, 1, 0)})`}}>{children}</div>
);

/* ---------- Captions ---------- */
export type Cap = [number, number, string];
export const Caption: React.FC<{caps: Cap[]; noCap: number[][]; t: number}> = ({caps, noCap, t}) => {
  if (noCap.some(([a, b]) => t >= a && t < b)) return null;
  const c = caps.find(([a, b]) => t >= a && t < b + 0.05);
  if (!c) return null;
  const k = clamp(t, c[0], c[0] + 0.2);
  const parts = c[2].split('*');
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 70, textAlign: 'center', opacity: k, transform: `translateY(${(1 - k) * 24}px)`, fontFamily, fontWeight: 700, fontSize: 68, color: '#fff', WebkitTextStroke: `11px ${INK}`, paintOrder: 'stroke fill', whiteSpace: 'nowrap'}}>
      {parts.map((s, i) => <span key={i} style={i % 2 ? {color: GOLD} : undefined}>{s}</span>)}
    </div>
  );
};
