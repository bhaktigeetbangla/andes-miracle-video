import React from 'react';
import {AbsoluteFill, random} from 'remotion';
import {INK, SW} from './theme';

const sh = {stroke: INK, strokeWidth: SW, strokeLinejoin: 'round' as const};

/** 100% full-screen SVG layer (1920x1080 coordinates, edge-to-edge) */
export const Svg: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <AbsoluteFill>
    <svg width="100%" height="100%" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice">{children}</svg>
  </AbsoluteFill>
);

export const Sky: React.FC<{a: string; b: string; id?: string}> = ({a, b, id = 'sky'}) => (
  <g>
    <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} /></linearGradient></defs>
    <rect x={-10} y={-10} width={1940} height={1100} fill={`url(#${id})`} />
  </g>
);

export const Vignette: React.FC<{color?: string; op?: number}> = ({color = '#000', op = 0.4}) => (
  <g>
    <defs><radialGradient id="vg" cx="0.5" cy="0.5" r="0.75"><stop offset="0.55" stopColor={color} stopOpacity={0} /><stop offset="1" stopColor={color} stopOpacity={op} /></radialGradient></defs>
    <rect x={-10} y={-10} width={1940} height={1100} fill="url(#vg)" />
  </g>
);

export const Clouds: React.FC<{t: number; ys: number[]; color?: string; speed?: number; size?: number; op?: number}> = ({t, ys, color = '#ffffff', speed = 40, size = 1, op = 0.95}) => (
  <g opacity={op}>
    {ys.map((y, i) => {
      const w = 2300;
      const x = (((random('c' + i + y) * w - t * speed * (0.6 + random('cs' + i) * 0.8)) % w) + w) % w - 200;
      return (
        <g key={i} transform={`translate(${x} ${y}) scale(${size * (0.8 + random('cz' + i) * 0.7)})`} fill={color}>
          <ellipse cx={0} cy={0} rx={110} ry={34} /><ellipse cx={-70} cy={8} rx={70} ry={28} /><ellipse cx={75} cy={6} rx={80} ry={30} /><ellipse cx={20} cy={-22} rx={60} ry={32} />
        </g>
      );
    })}
  </g>
);

export const Peaks: React.FC<{pts: number[][]; color: string; snow?: string; dx?: number; dy?: number}> = ({pts, color, snow = '#ffffff', dx = 0, dy = 0}) => {
  const d = `M ${pts[0][0]} 1100 ` + pts.map((p) => `L ${p[0]} ${p[1]}`).join(' ') + ` L ${pts[pts.length - 1][0]} 1100 Z`;
  const caps = pts.map((p, i) => {
    if (i === 0 || i === pts.length - 1) return null;
    const a = pts[i - 1], b = pts[i + 1];
    if (!(p[1] < a[1] && p[1] < b[1])) return null;
    const A = [p[0] + (a[0] - p[0]) * 0.3, p[1] + (a[1] - p[1]) * 0.3];
    const B = [p[0] + (b[0] - p[0]) * 0.3, p[1] + (b[1] - p[1]) * 0.3];
    return <polygon key={i} points={`${A[0]},${A[1]} ${p[0]},${p[1]} ${B[0]},${B[1]} ${B[0] - (B[0] - p[0]) * 0.35},${B[1] + 16} ${p[0]},${A[1] + 26} ${A[0] + (p[0] - A[0]) * 0.35},${A[1] + 16}`} fill={snow} stroke={INK} strokeWidth={2} strokeLinejoin="round" />;
  });
  return <g transform={`translate(${dx} ${dy})`}><path d={d} fill={color} {...sh} />{caps}</g>;
};
export const FAR: number[][] = [[-100, 640], [150, 470], [380, 600], [640, 380], [900, 580], [1180, 430], [1450, 590], [1700, 400], [2020, 620]];
export const NEAR: number[][] = [[-100, 760], [220, 560], [520, 740], [860, 520], [1180, 730], [1500, 560], [1800, 720], [2020, 640]];

export const Ground: React.FC<{y: number; color?: string}> = ({y, color = '#f4f9fd'}) => (
  <g>
    <path d={`M -20 ${y} Q 400 ${y - 40} 900 ${y - 10} T 1940 ${y - 30} L 1940 1100 L -20 1100Z`} fill={color} {...sh} />
    <path d={`M -20 ${y + 90} Q 500 ${y + 60} 1000 ${y + 100} T 1940 ${y + 80}`} fill="none" stroke="#c6dbeb" strokeWidth={5} />
  </g>
);

export const Snow: React.FC<{t: number; n?: number; speed?: number; wind?: number}> = ({t, n = 70, speed = 160, wind = 60}) => (
  <g fill="#fff" opacity={0.85}>
    {Array.from({length: n}).map((_, i) => {
      const x = (((random('sx' + i) * 2000 + t * wind * (0.5 + random('sw' + i))) % 2000) + 2000) % 2000 - 40;
      const y = ((random('sy' + i) * 1100 + t * speed * (0.5 + random('sv' + i))) % 1100) - 10;
      return <circle key={i} cx={x} cy={y} r={2 + random('sr' + i) * 4} />;
    })}
  </g>
);

export const Fuselage: React.FC<{t: number}> = ({t}) => (
  <g>
    <rect x={-10} y={-10} width={1940} height={1100} fill="#56667a" />
    <path d="M -10 -10 L 1930 -10 L 1930 200 Q 960 120 -10 200Z" fill="#3e4c5e" />
    <rect x={-10} y={880} width={1940} height={220} fill="#3a4350" />
    {[140, 560, 980, 1400].map((x, i) => (
      <g key={i}>
        <rect x={x} y={250} width={300} height={190} rx={60} fill="#dff1fb" {...sh} />
        <path d={`M ${x + 20} 420 L ${x + 120} 270 L ${x + 170} 270 L ${x + 70} 420Z`} fill="#fff" opacity={0.5} />
      </g>
    ))}
    {[260, 880, 1500].map((x, i) => (<g key={i}><rect x={x} y={760} width={150} height={150} rx={26} fill="#7a4d4d" {...sh} /><rect x={x + 10} y={700} width={130} height={90} rx={24} fill="#8d5a5a" {...sh} /></g>))}
    <rect x={-10} y={-10} width={1940} height={1100} fill="#9ac8ee" opacity={0.08 + 0.03 * Math.sin(t * 2)} />
  </g>
);

type Part = {dx: number; dy: number; r: number};
export const Plane: React.FC<{x: number; y: number; s?: number; rot?: number; t: number; tail?: Part; wing?: Part; hideTail?: boolean; hideWing?: boolean}> = ({x, y, s = 1, rot = 0, t, tail, wing, hideTail, hideWing}) => {
  const pr = Math.abs(Math.cos(t * 40)) * 52 + 6;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
      {!hideTail && (
        <g transform={`translate(${tail?.dx ?? 0} ${tail?.dy ?? 0}) rotate(${tail?.r ?? 0} -150 0)`}>
          <path d="M -120 -42 L -190 -40 L -200 36 L -120 40Z" fill="#fff" {...sh} />
          <path d="M -150 -40 L -215 -125 L -180 -125 L -125 -40Z" fill="#2f6fdd" {...sh} />
          <path d="M -200 -30 L -215 -20 L -204 -8 L -216 6 L -202 18 L -200 36" fill="none" stroke={INK} strokeWidth={2} />
        </g>
      )}
      <path d="M -120 -42 L 140 -46 Q 218 -42 224 0 Q 218 40 140 44 L -120 40Z" fill="#fff" {...sh} />
      <path d="M -120 8 L 220 10 L 218 24 L -120 24Z" fill="#2f6fdd" {...sh} />
      <path d="M 150 -44 L 205 -34 L 214 -6 L 150 -6Z" fill="#9fd4f5" {...sh} />
      {[-80, -30, 20, 70].map((wx) => <circle key={wx} cx={wx} cy={-12} r={10} fill="#bfe3fa" {...sh} />)}
      {!hideWing && (
        <g transform={`translate(${wing?.dx ?? 0} ${wing?.dy ?? 0}) rotate(${wing?.r ?? 0} 20 20)`}>
          <path d="M -40 26 L 80 26 L 50 74 L -70 74Z" fill="#d6dee8" {...sh} />
          <rect x={-70} y={74} width={120} height={7} fill="#2f6fdd" stroke={INK} strokeWidth={2} />
        </g>
      )}
      <rect x={222} y={-6} width={10} height={12} fill="#555" />
      <ellipse cx={232} cy={0} rx={6} ry={pr} fill="#555" opacity={0.7} />
    </g>
  );
};

export const Heli: React.FC<{x: number; y: number; s?: number; t: number}> = ({x, y, s = 1, t}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-250} y={-18} width={190} height={22} rx={10} fill="#d63a3a" {...sh} />
    <path d="M -240 -14 L -270 -70 L -250 -70 L -218 -14Z" fill="#d63a3a" {...sh} />
    <ellipse cx={0} cy={0} rx={100} ry={56} fill="#d63a3a" {...sh} />
    <path d="M 20 -44 Q 90 -40 96 0 L 20 0Z" fill="#bfe3fa" {...sh} />
    <rect x={-60} y={-10} width={60} height={20} fill="#fff" opacity={0.85} />
    <rect x={-4} y={-72} width={8} height={20} fill={INK} />
    <ellipse cx={0} cy={-74} rx={30 + 260 * Math.abs(Math.cos(t * 28))} ry={5} fill="#333" opacity={0.75} />
    <line x1={-70} y1={78} x2={80} y2={78} stroke={INK} strokeWidth={7} strokeLinecap="round" />
    <line x1={-40} y1={50} x2={-48} y2={78} stroke={INK} strokeWidth={5} /><line x1={40} y1={50} x2={48} y2={78} stroke={INK} strokeWidth={5} />
  </g>
);

/* -------- Icons (centered at 0,0, roughly ±40) -------- */
export const IcoWarn: React.FC = () => (<g><path d="M 0 -40 L 42 32 L -42 32Z" fill="#ffd23f" {...sh} /><text x={0} y={22} textAnchor="middle" fontSize={50} fontWeight={700} fill={INK}>!</text></g>);
export const IcoQ: React.FC = () => (<g><circle r={38} fill="#ffd23f" {...sh} /><text x={0} y={16} textAnchor="middle" fontSize={54} fontWeight={700} fill={INK}>?</text></g>);
export const IcoAlert: React.FC = () => (<g><circle r={38} fill="#e04848" {...sh} /><text x={0} y={17} textAnchor="middle" fontSize={56} fontWeight={700} fill="#fff">!</text></g>);
export const IcoCompass: React.FC<{t: number}> = ({t}) => (<g><circle r={38} fill="#fff" {...sh} /><g transform={`rotate(${Math.sin(t * 5) * 70 + t * 60})`}><path d="M 0 -30 L 9 0 L -9 0Z" fill="#e04848" /><path d="M 0 30 L 9 0 L -9 0Z" fill="#555" /></g><circle r={4} fill={INK} /></g>);
export const IcoCan: React.FC = () => (<g><rect x={-24} y={-28} width={48} height={58} rx={7} fill="#d9a441" {...sh} /><rect x={-24} y={-12} width={48} height={22} fill="#fff" stroke={INK} strokeWidth={2} /><ellipse cx={0} cy={-28} rx={24} ry={6} fill="#bbb" {...sh} /></g>);
export const IcoMed: React.FC = () => (<g><rect x={-34} y={-34} width={68} height={68} rx={14} fill="#fff" {...sh} /><rect x={-9} y={-24} width={18} height={48} fill="#e04848" /><rect x={-24} y={-9} width={48} height={18} fill="#e04848" /></g>);
export const IcoGlobe: React.FC<{cross?: boolean}> = ({cross}) => (<g><circle r={36} fill="#4aa3e8" {...sh} /><ellipse rx={14} ry={36} fill="none" stroke={INK} strokeWidth={2} /><line x1={-36} y1={0} x2={36} y2={0} stroke={INK} strokeWidth={2} /><path d="M -22 -20 Q -6 -12 -14 4 Q -26 0 -22 -20Z M 8 4 Q 24 0 20 20 Q 6 22 8 4Z" fill="#6cc070" />{cross && <g stroke="#e04848" strokeWidth={9} strokeLinecap="round"><line x1={-30} y1={-30} x2={30} y2={30} /><line x1={30} y1={-30} x2={-30} y2={30} /></g>}</g>);
export const IcoThermo: React.FC<{lvl: number}> = ({lvl}) => (<g><rect x={-12} y={-44} width={24} height={72} rx={12} fill="#fff" {...sh} /><circle cx={0} cy={32} r={19} fill="#e04848" {...sh} /><rect x={-5} y={-36 + (1 - lvl) * 62} width={10} height={62 * lvl + 6} rx={5} fill="#e04848" /></g>);
export const IcoNote: React.FC = () => (<g><path d="M -28 -34 L 22 -34 L 32 -24 L 32 34 L -28 34Z" fill="#fff8dc" {...sh} />{[-16, -4, 8, 20].map((y) => <line key={y} x1={-18} y1={y} x2={22} y2={y} stroke="#999" strokeWidth={2.5} />)}</g>);
export const IcoHeart: React.FC<{c?: string}> = ({c = '#e04848'}) => (<path d="M 0 34 C -56 -6 -30 -46 0 -16 C 30 -46 56 -6 0 34Z" fill={c} {...sh} />);
export const IcoBall: React.FC = () => (<g transform="rotate(-30)"><ellipse rx={44} ry={26} fill="#8b4a22" {...sh} /><line x1={-14} y1={0} x2={14} y2={0} stroke="#fff" strokeWidth={3} />{[-8, 0, 8].map((x) => <line key={x} x1={x} y1={-6} x2={x} y2={6} stroke="#fff" strokeWidth={2} />)}</g>);
export const IcoRadio: React.FC<{t: number; waves?: boolean}> = ({t, waves = true}) => (<g><line x1={20} y1={-30} x2={44} y2={-70} stroke={INK} strokeWidth={4} /><rect x={-44} y={-30} width={88} height={60} rx={10} fill="#7b6a58" {...sh} /><circle cx={-18} cy={0} r={18} fill="#d9cdb8" {...sh} /><circle cx={24} cy={-10} r={6} fill="#e8d28a" {...sh} /><rect x={8} y={6} width={30} height={8} fill="#222" />{waves && [0, 1, 2].map((i) => <path key={i} d={`M ${54 + i * 14} -80 Q ${66 + i * 14} -66 ${54 + i * 14} -52`} fill="none" stroke="#fff" strokeWidth={4} opacity={0.4 + 0.6 * Math.abs(Math.sin(t * 5 - i))} />)}</g>);
export const IcoScale: React.FC<{t: number}> = ({t}) => (<g><rect x={-4} y={-30} width={8} height={72} fill={INK} /><rect x={-30} y={40} width={60} height={8} rx={4} fill={INK} /><g transform={`rotate(${Math.sin(t * 3) * 14} 0 -30)`}><line x1={-44} y1={-30} x2={44} y2={-30} stroke={INK} strokeWidth={6} strokeLinecap="round" /><path d="M -56 -12 L -32 -12 L -44 -30Z M 32 -12 L 56 -12 L 44 -30Z" fill="#ffd23f" {...sh} /></g></g>);
export const IcoCheck: React.FC<{c?: string}> = ({c = '#3aa76d'}) => (<g><circle r={32} fill={c} {...sh} /><path d="M -15 2 L -4 14 L 17 -10" fill="none" stroke="#fff" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" /></g>);
export const IcoCross: React.FC = () => (<g><circle r={32} fill="#e04848" {...sh} /><path d="M -13 -13 L 13 13 M 13 -13 L -13 13" stroke="#fff" strokeWidth={8} strokeLinecap="round" /></g>);
export const IcoPerson: React.FC<{c: string}> = ({c}) => (<g><circle cx={0} cy={-22} r={14} fill={c} {...sh} /><path d="M -22 36 Q -22 -4 0 -4 Q 22 -4 22 36Z" fill={c} {...sh} /></g>);
export const IcoFlame: React.FC = () => (<path d="M 0 -42 C 10 -22 34 -14 30 14 C 28 34 10 42 0 42 C -12 42 -30 34 -30 14 C -30 0 -16 -6 -14 -22 C -4 -14 -2 -28 0 -42Z" fill="#ff8a1f" {...sh} />);
export const IcoMount: React.FC = () => (<g><path d="M -44 34 L -10 -30 L 8 0 L 22 -18 L 46 34Z" fill="#7d8fa6" {...sh} /><path d="M -10 -30 L -22 -8 L -10 -14 L 0 -6Z" fill="#fff" {...sh} /></g>);
export const IcoLink: React.FC = () => (<g fill="none" stroke={INK} strokeWidth={6}><rect x={-44} y={-16} width={52} height={32} rx={16} stroke="#2f6fdd" /><rect x={-8} y={-16} width={52} height={32} rx={16} stroke="#e04848" /></g>);
export const IcoDown: React.FC = () => (<path d="M -20 -40 L 20 -40 L 20 0 L 40 0 L 0 42 L -40 0 L -20 0Z" fill="#e04848" {...sh} />);
export const IcoCal: React.FC<{label: string}> = ({label}) => (<g><rect x={-38} y={-38} width={76} height={76} rx={10} fill="#fff" {...sh} /><rect x={-38} y={-38} width={76} height={22} rx={10} fill="#e04848" {...sh} /><text x={0} y={26} textAnchor="middle" fontSize={40} fontWeight={700} fill={INK}>{label}</text></g>);

export const Suitcase: React.FC<{x: number; y: number; c: string; s?: number}> = ({x, y, c, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}><rect x={-50} y={-70} width={100} height={70} rx={10} fill={c} {...sh} /><rect x={-16} y={-84} width={32} height={16} rx={6} fill="none" stroke={INK} strokeWidth={4} /><line x1={-50} y1={-35} x2={50} y2={-35} stroke={INK} strokeWidth={2} opacity={0.4} /></g>
);
