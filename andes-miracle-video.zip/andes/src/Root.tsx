import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {DURATION, FPS} from './theme';

export const Root: React.FC = () => (
  <Composition id="AndesVideo" component={Video} durationInFrames={DURATION} fps={FPS} width={1920} height={1080} />
);
