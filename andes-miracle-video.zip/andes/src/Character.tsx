import React from 'react';
import {INK, SW} from './theme';

export type Hat = {t: 'wool' | 'straw' | 'pilot'; c: string};
export type Look = {
  skin: string; hair: string; style: 'messy' | 'short' | 'none'; hat?: Hat;
  jacket: string; inner?: string; pants: string; boots: string;
  beard?: 'stubble' | 'mustache' | 'thick'; scarf?: string; bag?: string; tie?: string;
  stripes?: boolean; thin?: boolean; blanket?: boolean;
};
export type Mood = 'neutral' | 'happy' | 'sad' | 'scared' | 'angry' | 'surprised' | 'determined' | 'tired';
export type Pose = 'stand' | 'walk' | 'up' | 'point' | 'hold' | 'cover' | 'wave';

export const LOOKS: Record<string, Look> = {
  parado: {skin: '#e8b894', hair: '#6b4a2f', style: 'messy', hat: {t: 'wool', c: '#8b5a2b'}, jacket: '#1f3b73', inner: '#8d8d8d', pants: '#222222', boots: '#7a4a22', beard: 'stubble'},
  canessa: {skin: '#e8b894', hair: '#1b1b1b', style: 'messy', hat: {t: 'wool', c: '#2b2b2b'}, jacket: '#d63a3a', pants: '#2e5fa8', boots: '#1b1b1b', bag: '#8b6b3a', thin: true},
  vizintin: {skin: '#efc7a5', hair: '#1b1b1b', style: 'short', jacket: '#3f9a4f', pants: '#222222', boots: '#8a8a8a', scarf: '#9a9a9a', thin: true},
  catalan: {skin: '#c98a5b', hair: '#1b1b1b', style: 'none', hat: {t: 'straw', c: '#e0c068'}, jacket: '#7a4a22', inner: '#ffffff', pants: '#9a7a52', boots: '#1b1b1b', beard: 'thick'},
  pilot: {skin: '#e8b894', hair: '#1b1b1b', style: 'short', hat: {t: 'pilot', c: '#1f3b73'}, jacket: '#1b2f5e', inner: '#ffffff', pants: '#1b2f5e', boots: '#111111', beard: 'mustache', tie: '#111111', stripes: true},
};
// নামহীন যাত্রী/উদ্ধারকর্মী (Extras)
export const CROWD: Look[] = [
  {skin: '#e8b894', hair: '#3a2a1a', style: 'messy', hat: {t: 'wool', c: '#3b5fa8'}, jacket: '#2f5fb0', pants: '#333333', boots: '#5a3a1a', scarf: '#cfcfcf', beard: 'stubble'},
  {skin: '#d9a77c', hair: '#1b1b1b', style: 'short', hat: {t: 'wool', c: '#b83a3a'}, jacket: '#c24040', pants: '#2a2a2a', boots: '#222222', scarf: '#8a8a8a', beard: 'stubble'},
  {skin: '#efc7a5', hair: '#5a3a1a', style: 'messy', jacket: '#8a8f98', pants: '#2e2e2e', boots: '#4a3a2a', blanket: true},
  {skin: '#c98a5b', hair: '#1b1b1b', style: 'short', hat: {t: 'wool', c: '#7a4a22'}, jacket: '#7b5a3a', pants: '#222222', boots: '#222222', beard: 'stubble', thin: true},
  {skin: '#e8b894', hair: '#2a1a0a', style: 'messy', hat: {t: 'wool', c: '#6b6b6b'}, jacket: '#3d6bb5', pants: '#333333', boots: '#3a2a1a', scarf: '#b83a3a', beard: 'stubble'},
  {skin: '#d9a77c', hair: '#1b1b1b', style: 'messy', jacket: '#a34a4a', pants: '#2a2a2a', boots: '#222222', blanket: true, thin: true},
];

type P = {
  look: Look; x: number; y: number; t: number; mood?: Mood; pose?: Pose; talk?: boolean;
  scale?: number; flip?: boolean; shake?: number; seed?: number; opacity?: number; tear?: boolean;
};

const sh = {stroke: INK, strokeWidth: SW, strokeLinejoin: 'round' as const};

export const Char: React.FC<P> = ({look: L, x, y, t, mood = 'neutral', pose = 'stand', talk = false, scale = 1, flip = false, shake = 0, seed = 0, opacity = 1, tear = false}) => {
  const f = t * 30 + seed * 17;
  const bob = Math.sin(f / 14) * 4;
  const jx = shake ? Math.sin(f * 2.7) * shake : 0;
  const jy = shake ? Math.cos(f * 3.1) * shake * 0.6 : 0;
  const blink = f % 96 < 4;
  const sw = Math.sin(f / 5);
  let la = 6, ra = -6, ll = 0, rl = 0;
  if (pose === 'walk') { la = sw * 35; ra = -sw * 35; ll = -sw * 22; rl = sw * 22; }
  if (pose === 'up') { la = 155 + Math.sin(f / 4) * 10; ra = -155 - Math.sin(f / 4 + 1) * 10; }
  if (pose === 'wave') { ra = -150 + Math.sin(f / 3) * 22; }
  if (pose === 'point') { ra = -95; }
  if (pose === 'hold') { la = 40; ra = -40; }
  if (pose === 'cover') { la = -55; ra = 55; }
  const bw = L.thin ? 72 : 84;
  const eyeR = mood === 'scared' || mood === 'surprised' ? 13 : 10;
  const brow = (s: number) => {
    let o = 0, i = 0, by = -270;
    if (mood === 'sad' || mood === 'scared') { o = 3; i = -6; }
    if (mood === 'angry' || mood === 'determined') { o = -3; i = 5; }
    if (mood === 'surprised') by = -279;
    if (mood === 'tired') { o = 2; i = -2; }
    return <line x1={s * 28} y1={by + o} x2={s * 8} y2={by + i} stroke={INK} strokeWidth={5} strokeLinecap="round" />;
  };
  const talkShape = Math.floor(f / 4) % 3;
  const mouth = () => {
    if (talk) {
      if (talkShape === 0) return <path d="M -10 -226 L 10 -226" {...sh} fill="none" />;
      if (talkShape === 1) return <ellipse cx={0} cy={-226} rx={8} ry={5} fill="#8b2d2d" {...sh} />;
      return <ellipse cx={0} cy={-224} rx={12} ry={11} fill="#8b2d2d" {...sh} />;
    }
    switch (mood) {
      case 'happy': return <path d="M -15 -230 Q 0 -210 15 -230" fill="#fff" {...sh} />;
      case 'sad': return <path d="M -12 -221 Q 0 -234 12 -221" fill="none" {...sh} />;
      case 'scared': return <ellipse cx={0} cy={-222} rx={9} ry={13} fill="#8b2d2d" {...sh} />;
      case 'surprised': return <ellipse cx={0} cy={-224} rx={9} ry={12} fill="#8b2d2d" {...sh} />;
      case 'angry': return <path d="M -13 -222 Q 0 -232 13 -222" fill="none" {...sh} />;
      case 'determined': return <path d="M -13 -226 L 13 -226" fill="none" {...sh} />;
      case 'tired': return <path d="M -9 -224 Q 0 -222 9 -224" fill="none" {...sh} />;
      default: return <path d="M -11 -226 Q 0 -221 11 -226" fill="none" {...sh} />;
    }
  };
  const darker = (c: string) => c;
  return (
    <g transform={`translate(${x + jx} ${y + bob + jy}) scale(${flip ? -scale : scale} ${scale})`} opacity={opacity}>
      <ellipse cx={0} cy={4 - bob} rx={58} ry={9} fill="#000" opacity={0.15} />
      {/* legs */}
      {[[-20, ll], [20, rl]].map(([lx, ang], i) => (
        <g key={i} transform={`rotate(${ang} ${lx} -105)`}>
          <rect x={lx - 13} y={-105} width={26} height={88} rx={13} fill={L.pants} {...sh} />
          <rect x={lx - 16} y={-28} width={44} height={28} rx={10} fill={L.boots} {...sh} />
        </g>
      ))}
      {/* body */}
      <rect x={-bw / 2} y={-208} width={bw} height={114} rx={32} fill={L.jacket} {...sh} />
      {L.inner && L.inner !== L.jacket && <rect x={-18} y={-208} width={36} height={34} rx={14} fill={L.inner} {...sh} />}
      {!L.blanket && <line x1={0} y1={-172} x2={0} y2={-96} stroke={INK} strokeWidth={2} opacity={0.5} />}
      {L.blanket && <path d={`M ${-bw / 2} -190 L ${bw / 2} -150 L ${bw / 2} -96 L ${-bw / 2} -96Z`} fill="#b9a27a" {...sh} />}
      {L.tie && <path d="M -7 -208 L 7 -208 L 5 -168 L 0 -158 L -5 -168Z" fill={L.tie} {...sh} />}
      {L.bag && (<g><line x1={-bw / 2 + 6} y1={-200} x2={bw / 2 - 4} y2={-112} stroke={L.bag} strokeWidth={8} /><rect x={bw / 2 - 24} y={-132} width={40} height={34} rx={8} fill={L.bag} {...sh} /></g>)}
      {/* arms */}
      {[[-1, la], [1, ra]].map(([s, ang], i) => (
        <g key={i} transform={`translate(${s * (bw / 2 + 4)} -192) rotate(${ang})`}>
          <rect x={-12} y={-4} width={24} height={92} rx={12} fill={L.jacket} {...sh} />
          {L.stripes && s === 1 && [10, 18, 26].map((yy) => <rect key={yy} x={-12} y={yy} width={24} height={4} fill="#e6b422" />)}
          <circle cx={0} cy={90} r={13} fill={L.skin} {...sh} />
        </g>
      ))}
      {/* neck + head */}
      <rect x={-10} y={-222} width={20} height={22} fill={L.skin} {...sh} />
      {L.scarf && <g><rect x={-32} y={-216} width={64} height={18} rx={9} fill={L.scarf} {...sh} /><rect x={8} y={-204} width={14} height={40} rx={6} fill={L.scarf} {...sh} /></g>}
      <circle cx={-44} cy={-256} r={9} fill={L.skin} {...sh} />
      <circle cx={44} cy={-256} r={9} fill={L.skin} {...sh} />
      <ellipse cx={0} cy={-258} rx={44} ry={48} fill={L.skin} {...sh} />
      {L.style === 'messy' && !L.hat && <path d="M -46 -270 Q -52 -322 -10 -314 Q 0 -328 16 -314 Q 52 -320 46 -270 Q 30 -292 0 -290 Q -30 -292 -46 -270Z" fill={L.hair} {...sh} />}
      {L.style === 'short' && !L.hat && <path d="M -45 -268 Q -46 -314 0 -314 Q 46 -314 45 -268 Q 30 -290 0 -288 Q -30 -290 -45 -268Z" fill={L.hair} {...sh} />}
      {L.hat && L.style !== 'none' && [-1, 1].map((s) => <ellipse key={s} cx={s * 42} cy={-262} rx={7} ry={13} fill={L.hair} />)}
      {/* face */}
      {L.beard === 'stubble' && <path d="M -42 -250 Q -44 -212 0 -210 Q 44 -212 42 -250 Q 30 -232 0 -232 Q -30 -232 -42 -250Z" fill="#222" opacity={0.28} />}
      {L.beard === 'thick' && <path d="M -22 -234 Q -12 -250 0 -239 Q 12 -250 22 -234 Q 36 -226 26 -226 Q 12 -230 0 -234 Q -12 -230 -26 -226 Q -36 -226 -22 -234Z" fill={L.hair} {...sh} />}
      {L.beard === 'mustache' && <path d="M -18 -236 Q -8 -246 0 -238 Q 8 -246 18 -236 Q 8 -231 0 -234 Q -8 -231 -18 -236Z" fill={L.hair} {...sh} />}
      <path d="M 0 -246 Q 7 -238 0 -236" fill="none" stroke={INK} strokeWidth={2} />
      {[-1, 1].map((s) => (
        <g key={s}>
          <ellipse cx={s * 17} cy={-252} rx={eyeR * 0.9} ry={blink ? 1.5 : eyeR} fill="#fff" {...sh} />
          {!blink && <circle cx={s * 17 + 2} cy={-251} r={mood === 'scared' ? 3.5 : 5} fill={INK} />}
          {mood === 'tired' && <rect x={s * 17 - 10} y={-264} width={20} height={13} fill={L.skin} />}
          {mood === 'tired' && <line x1={s * 17 - 10} y1={-251} x2={s * 17 + 10} y2={-251} stroke={INK} strokeWidth={2.5} />}
          {brow(s)}
        </g>
      ))}
      {tear && <ellipse cx={-17} cy={-240 + ((f % 40) / 40) * 22} rx={4} ry={6} fill="#5bb8ff" opacity={1 - (f % 40) / 60} />}
      {mouth()}
      {/* hats */}
      {L.hat && (L.hat.t === 'wool' || L.hat.t === 'pilot') && (
        <g>
          <path d="M -49 -280 Q -52 -346 0 -346 Q 52 -346 49 -280Z" fill={L.hat.c} {...sh} />
          {L.hat.t === 'wool' && [-24, 0, 24].map((xx) => <line key={xx} x1={xx} y1={-342} x2={xx} y2={-296} stroke={INK} strokeWidth={1.5} opacity={0.3} />)}
          <rect x={-52} y={-296} width={104} height={22} rx={11} fill={darker(L.hat.c)} {...sh} />
          {L.hat.t === 'wool' && <circle cx={0} cy={-352} r={11} fill={L.hat.c} {...sh} />}
          {L.hat.t === 'pilot' && <><ellipse cx={34} cy={-276} rx={34} ry={7} fill="#111" /><circle cx={0} cy={-322} r={8} fill="#e6b422" {...sh} /></>}
        </g>
      )}
      {L.hat && L.hat.t === 'straw' && (
        <g>
          <ellipse cx={0} cy={-290} rx={86} ry={16} fill={L.hat.c} {...sh} />
          <path d="M -46 -290 Q -46 -342 0 -342 Q 46 -342 46 -290Z" fill={L.hat.c} {...sh} />
          <rect x={-46} y={-304} width={92} height={11} fill="#8b5a2b" stroke={INK} strokeWidth={2} />
        </g>
      )}
    </g>
  );
};
