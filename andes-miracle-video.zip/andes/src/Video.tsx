import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {FPS} from './theme';
import {fontFamily} from './font';
import {Caption} from './UI';
import {CAPS, NO_CAP} from './captions';
import {SC, S1, S2, S3, S4, S5, S6, S7} from './Scenes1';
import {S8, S9, S10, S11, S12, S13, S14} from './Scenes2';

const SCENES = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13, S14];

export const Video: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  return (
    <AbsoluteFill style={{background: '#0e1a33', fontFamily}}>
      <Audio src={staticFile('voice.mp3')} />
      {SCENES.map((Scene, i) => {
        const from = Math.round(SC[i][0] * FPS);
        const end = Math.round(SC[i][1] * FPS);
        return (
          <Sequence key={i} from={from} durationInFrames={end - from}>
            <Scene />
          </Sequence>
        );
      })}
      <Caption caps={CAPS} noCap={NO_CAP} t={t} />
    </AbsoluteFill>
  );
};
