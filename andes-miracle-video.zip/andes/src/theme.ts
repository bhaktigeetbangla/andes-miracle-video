export const FPS = 30;
export const DURATION = 6696; // 223.2s
export const INK = '#222222';
export const SW = 2.5;
export const GOLD = '#ffd23f';
export const RED = '#e04848';
