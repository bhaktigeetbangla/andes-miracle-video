import React from 'react';
import {Svg, Sky, Clouds, Peaks, FAR, NEAR, Ground, Snow, Fuselage, Vignette, Plane, Heli, IcoQ, IcoAlert, IcoCompass, IcoCan, IcoMed, IcoGlobe, IcoThermo, IcoBall, IcoRadio, IcoDown, IcoWarn, IcoPerson, IcoCross, Suitcase} from './Art';
import {Char, LOOKS, CROWD} from './Character';
import {Card, IconAt, Pill, Stamp, Thought, Shake, Flash, Wrap} from './UI';
import {clamp, vis, pop, popOut, lerp, ease, useT} from './util';
import {INK} from './theme';

export const SC: [number, number][] = [
  [0, 15], [15, 24.2], [24.2, 37.5], [37.5, 53.7], [53.7, 61.4], [61.4, 71.9], [71.9, 95.2],
  [95.2, 115.2], [115.2, 127.5], [127.5, 145.4], [145.4, 171.9], [171.9, 183.7], [183.7, 208.9], [208.9, 223.2],
];

/* ১: আকাশে বিমান */
export const S1: React.FC = () => {
  const S = 0, t = useT(S);
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Sky a="#6fbdf0" b="#e3f4ff" id="s1" />
        <Peaks pts={FAR} color="#9fb4c9" dy={330} />
        <Clouds t={t} ys={[160, 330, 560, 760]} speed={55} />
        <Plane x={960 + Math.sin(t * 1.1) * 40} y={470 + Math.sin(t * 2) * 14} s={1.7} rot={Math.sin(t * 1.1) * 2} t={t} />
        <Clouds t={t + 5} ys={[880]} speed={90} size={1.3} />
      </Svg>
      <Pill y={60} op={vis(t, 0.1, 3.2)}>১৩ অক্টোবর, ১৯৭২</Pill>
      <Stamp x={960} y={800} p={popOut(t, 7.4, 9.2)} color="#2f6fdd">৪৫ জন</Stamp>
      <IconAt x={1500 + Math.sin(t * 3) * 20} y={250 + Math.sin(t * 2) * 12} size={190} p={popOut(t, 11.0, 14.5)} rot={Math.sin(t * 3) * 15}><IcoBall /></IconAt>
      <IconAt x={420} y={250} size={170} p={popOut(t, 12.8, 14.9)}><g><IcoPerson c="#e04848" /><g transform="translate(34 6) scale(.8)"><IcoPerson c="#3aa76d" /></g></g></IconAt>
    </Wrap>
  );
};

/* ২: গন্তব্য সান্তিয়াগো + অশুভ আভাস (মোশন গ্রাফিক্স) */
export const S2: React.FC = () => {
  const S = 15, t = useT(S);
  const u = ease(clamp(t, 15, 24.2, 0, 0.9));
  const B = (k: number) => [(1 - k) * (1 - k) * 360 + 2 * k * (1 - k) * 960 + k * k * 1560, (1 - k) * (1 - k) * 720 + 2 * k * (1 - k) * 260 + k * k * 600];
  const [px, py] = B(u);
  const [qx, qy] = B(u + 0.02);
  const ang = (Math.atan2(qy - py, qx - px) * 180) / Math.PI;
  const dark = clamp(t, 17.8, 20.5);
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Sky a="#13264d" b="#2c4f8f" id="s2" />
        {[...Array(40)].map((_, i) => <circle key={i} cx={(i * 197) % 1900} cy={(i * 83) % 500} r={2 + (i % 3)} fill="#fff" opacity={0.4} />)}
        <path d="M 360 720 Q 960 260 1560 600" fill="none" stroke="#ffd23f" strokeWidth={8} strokeDasharray="4 24" strokeLinecap="round" />
        <circle cx={360} cy={720} r={22} fill="#e04848" stroke={INK} strokeWidth={4} />
        <circle cx={1560} cy={600} r={22} fill="#3aa76d" stroke={INK} strokeWidth={4} />
        <Plane x={px} y={py} s={0.4} rot={ang} t={t} />
        <rect x={-10} y={-10} width={1940} height={1100} fill="#7a0d0d" opacity={dark * 0.5} />
        <Vignette op={0.55} />
      </Svg>
      <Card x={360} y={800} p={pop(t, 15.2)} size={44} bg="#fff">উরুগুয়ে</Card>
      <Card x={1560} y={680} p={pop(t, 16.0)} size={44} bg="#fff">চিলি · সান্তিয়াগো</Card>
      <IconAt x={960} y={180} size={200} p={vis(t, 18.4, 24.2) * (1 + 0.1 * Math.sin(t * 8))}><IcoQ /></IconAt>
      <Card x={960} y={600} p={popOut(t, 20.6, 24.2)} size={84} bg="#e04848" color="#fff">সবচেয়ে ভয়ংকর অভিজ্ঞতা</Card>
    </Wrap>
  );
};

/* ৩: মেঘ ও দিক হারানো (ককপিট) */
export const S3: React.FC = () => {
  const S = 24.2, t = useT(S);
  return (
    <Wrap S={S} t={t}>
      <Shake amp={t > 27 ? 3 : 1} t={t}>
        <Svg>
          <Sky a="#5f6b78" b="#aab4be" id="s3" />
          <Clouds t={t} ys={[100, 260, 420, 600, 780]} color="#d7dde3" speed={420} size={2.6} op={0.9} />
          <Char look={LOOKS.pilot} x={600} y={1000} scale={2.1} t={t} mood={t > 30.6 ? 'scared' : 'tired'} shake={t > 30.6 ? 2 : 0} talk={t > 30.6 && t < 33} />
          <Char look={{...LOOKS.pilot, hair: '#5a3a1a', beard: undefined}} x={1280} y={1000} scale={2.1} t={t} mood={t > 30.6 ? 'scared' : 'neutral'} seed={3} flip />
          <rect x={-10} y={820} width={1940} height={300} fill="#2b3342" stroke={INK} strokeWidth={4} />
          {[260, 520, 780, 1140, 1400, 1660].map((x, i) => <circle key={i} cx={x} cy={930} r={50} fill="#d8e2ee" stroke={INK} strokeWidth={4} />)}
          {[260, 520, 780, 1140, 1400, 1660].map((x, i) => <line key={i} x1={x} y1={930} x2={x + 30 * Math.cos(t * (2 + i))} y2={930 + 30 * Math.sin(t * (2 + i))} stroke="#e04848" strokeWidth={6} strokeLinecap="round" />)}
          <path d="M -10 -10 L 330 -10 L 120 830 L -10 830Z M 1930 -10 L 1590 -10 L 1800 830 L 1930 830Z" fill="#2b3342" stroke={INK} strokeWidth={4} />
        </Svg>
        <Thought x={640} y={300} tx={640} ty={540} p={popOut(t, 30.6, 37.2)}><svg width={140} height={140} viewBox="-50 -50 100 100"><IcoCompass t={t} /></svg></Thought>
        <IconAt x={1700} y={420 + ((t * 120) % 200)} size={170} p={vis(t, 35.2, 37.5)}><IcoDown /></IconAt>
      </Shake>
    </Wrap>
  );
};

/* ৪: পাহাড়, ধাক্কা ও পিছলে থামা */
export const S4: React.FC = () => {
  const S = 37.5, t = useT(S);
  const crash = 46.2, slide = 49.8;
  const d = Math.max(0, t - crash);
  const flying = t < slide;
  const mt = ease(clamp(t, 37.6, 40.6));
  const px = t < crash ? lerp(150, 1150, clamp(t, 37.5, crash)) : 0;
  const slideP = ease(clamp(t, slide, 53.4));
  return (
    <Wrap S={S} t={t}>
      <Shake amp={t > crash && t < 49.6 ? 14 : 0} t={t}>
        {flying ? (
          <Svg>
            <Sky a="#8fa6bd" b="#d9e6f2" id="s4" />
            <g transform={`translate(0 ${(1 - mt) * 700})`}>
              <Peaks pts={[[600, 1100], [1000, 700], [1600, 160], [1950, 600], [2100, 1100]]} color="#7d8fa6" />
            </g>
            <Clouds t={t} ys={[200, 700, 900]} speed={120} size={1.8} op={0.7} />
            {t < crash ? (
              <Plane x={px} y={lerp(300, 470, clamp(t, 37.5, crash))} s={1.0} rot={lerp(0, 10, clamp(t, 37.5, crash))} t={t} />
            ) : (
              <Plane x={1150 + d * 20} y={470 + d * 10} s={1.0} rot={10} t={t} tail={{dx: -d * 220, dy: d * 140, r: -d * 90}} wing={{dx: d * 40, dy: d * 190, r: d * 80}} />
            )}
            {t > crash && [...Array(16)].map((_, i) => <circle key={i} cx={1150 + Math.cos(i * 1.7) * d * 160} cy={470 - Math.abs(Math.sin(i)) * d * 120 + d * d * 60} r={7 + (i % 4) * 3} fill="#fff" stroke={INK} strokeWidth={2} />)}
          </Svg>
        ) : (
          <Svg>
            <Sky a="#9db3c8" b="#e4eef7" id="s4b" />
            <Peaks pts={FAR} color="#8ea3ba" dy={150} />
            <Ground y={760} />
            <Snow t={t} n={40} />
            {[...Array(14)].map((_, i) => <circle key={i} cx={lerp(260, 1050, slideP) - 120 - i * 22} cy={800 + (i % 5) * 10 - (i * 7) % 24} r={16 - i} fill="#fff" stroke={INK} strokeWidth={2} opacity={1 - slideP * 0.8} />)}
            <Plane x={lerp(260, 1050, slideP)} y={800} s={1.1} rot={lerp(-6, 0, slideP)} t={t} hideTail hideWing />
            <g transform={`translate(${lerp(260, 1050, slideP) - 340} 770)`}><path d="M 0 0 L 90 -6 L 80 40 L 0 36Z" fill="#fff" stroke={INK} strokeWidth={2.5} /></g>
            {slideP > 0.95 && <g transform="translate(560 860) rotate(18)"><path d="M -90 -20 L 90 -10 L 70 30 L -90 20Z" fill="#d6dee8" stroke={INK} strokeWidth={2.5} /></g>}
          </Svg>
        )}
        <Thought x={760} y={230} tx={900} ty={380} p={popOut(t, 41.4, 43.5)} w={200} h={150}><svg width={120} height={120} viewBox="-50 -50 100 100"><IcoAlert /></svg></Thought>
        <IconAt x={1750} y={150} size={160} p={t > 37.6 && t < 46 ? 1 + 0.15 * Math.sin(t * 10) : 0}><IcoWarn /></IconAt>
      </Shake>
      <Flash t={t} a={crash} />
      <Flash t={t} a={slide} d={0.25} />
    </Wrap>
  );
};

/* ৫: ৪৫ জনের মধ্যে অনেকে মারা গেলেন (ইনফোগ্রাফিক) */
export const S5: React.FC = () => {
  const S = 53.7, t = useT(S);
  const dead = new Set([2, 5, 9, 11, 14, 18, 20, 23, 27, 31, 36, 40]);
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Sky a="#0e1a33" b="#1f3a66" id="s5" />
        {[...Array(45)].map((_, i) => {
          const cx = 360 + (i % 9) * 150, cy = 360 + Math.floor(i / 9) * 130;
          const appear = pop(t, 53.9 + i * 0.03);
          const gray = dead.has(i) ? clamp(t, 55.3 + (i % 5) * 0.2, 56.6) : 0;
          return <g key={i} transform={`translate(${cx} ${cy}) scale(${appear * 1.2})`}><IcoPerson c={gray > 0.5 ? '#6b7280' : '#5ec8ff'} /></g>;
        })}
        <Vignette op={0.6} />
        <rect x={-10} y={-10} width={1940} height={1100} fill="#e04848" opacity={0.18 * vis(t, 57.3, 61.4) * (0.6 + 0.4 * Math.sin(t * 6))} />
      </Svg>
      <Card x={960} y={150} p={popOut(t, 53.8, 57.2)} size={80} bg="#fff">৪৫ জন যাত্রী</Card>
      <IconAt x={960} y={920} size={210} p={popOut(t, 57.3, 61.4) * (1 + 0.1 * Math.sin(t * 8))}><IcoWarn /></IconAt>
    </Wrap>
  );
};

/* ৬: বরফ, ঠান্ডা, কিছুই নেই */
export const S6: React.FC = () => {
  const S = 61.4, t = useT(S);
  const rows: [number, React.ReactNode, string][] = [
    [66.1, <IcoCan />, 'খাবার নেই'], [67.8, <IcoMed />, 'চিকিৎসা নেই'], [69.5, <IcoGlobe />, 'যোগাযোগ নেই'],
  ];
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Sky a="#8da2b8" b="#dbe7f2" id="s6" />
        <Peaks pts={FAR} color="#8ea3ba" dy={20} />
        <Peaks pts={NEAR} color="#b7c9db" dy={80} />
        <Ground y={820} />
        <Plane x={470} y={860} s={0.9} rot={-3} t={t} hideTail hideWing />
        <Snow t={t} n={110} speed={260} wind={260} />
        <Vignette color="#1b2a44" op={0.35} />
      </Svg>
      <IconAt x={330} y={330} size={300} p={popOut(t, 63.8, 71.8)}><IcoThermo lvl={clamp(t, 63.8, 66, 0.9, 0.12)} /></IconAt>
      {rows.map(([at, ic, label], i) => (
        <Card key={i} x={1330 + (1 - pop(t, at)) * 600} y={260 + i * 190} p={Math.min(1, pop(t, at)) * clamp(t, 71.6, 71.9, 1, 0)} size={58} bg="#fff">
          <svg width={90} height={90} viewBox="-50 -50 100 100">{ic}</svg><span>{label}</span>
          <svg width={64} height={64} viewBox="-50 -50 100 100"><IcoCross /></svg>
        </Card>
      ))}
    </Wrap>
  );
};

/* ৭: ভাঙা বিমানে আশ্রয়, রেডিওর খবর */
export const S7: React.FC = () => {
  const S = 71.9, t = useT(S);
  const xs = [300, 560, 820, 1080, 1340, 1620];
  return (
    <Wrap S={S} t={t}>
      <Svg>
        <Fuselage t={t} />
        {[75.5, 76.1, 76.8].map((a, i) => <g key={i} opacity={pop(t, a) > 0 ? 1 : 0} transform={`translate(0 ${(1 - Math.min(1, pop(t, a))) * -80})`}><Suitcase x={290 + i * 420} y={450} c={['#8b5a2b', '#3b5fa8', '#b83a3a'][i]} s={1.6} /></g>)}
        {xs.map((x, i) => (
          <Char key={i} look={CROWD[i]} x={x} y={1000} scale={1.35} t={t} seed={i} pose="cover" mood={t > 79.8 && t < 81.6 ? 'scared' : t > 88 ? 'sad' : 'tired'} shake={t < 79.8 ? 1.5 : 0} tear={t > 91.7 && i === 2} />
        ))}
        <g opacity={vis(t, 81.6, 95.2)}><g transform="translate(960 930) scale(1.5)"><IcoRadio t={t} /></g></g>
        <rect x={-10} y={-10} width={1940} height={1100} fill="#0e2040" opacity={0.25} />
        <Vignette op={0.5} />
      </Svg>
      <Thought x={960} y={190} tx={960} ty={420} p={popOut(t, 79.8, 81.5)}><svg width={130} height={130} viewBox="-50 -50 100 100"><IcoCan /></svg></Thought>
      <Stamp x={960} y={300} p={popOut(t, 88.2, 91.6)} size={120}>খোঁজ বন্ধ!</Stamp>
      <Thought x={960} y={230} tx={960} ty={480} p={popOut(t, 91.8, 95.2)}><svg width={140} height={140} viewBox="-50 -50 100 100"><IcoGlobe cross /></svg></Thought>
    </Wrap>
  );
};
