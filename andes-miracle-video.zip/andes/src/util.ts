import {interpolate, useCurrentFrame} from 'remotion';
import {FPS} from './theme';

export const clamp = (t: number, a: number, b: number, from = 0, to = 1) =>
  interpolate(t, [a, b], [from, to], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
/** fade in at a, fade out at b */
export const vis = (t: number, a: number, b: number, f = 0.25) => Math.min(clamp(t, a, a + f), clamp(t, b - f, b, 1, 0));
/** springy pop-in starting at a (0 -> ~1 with overshoot) */
export const pop = (t: number, a: number) => {
  const x = t - a;
  return x <= 0 ? 0 : 1 - Math.exp(-x * 9) * Math.cos(x * 13);
};
/** pop in at a, shrink out at b */
export const popOut = (t: number, a: number, b: number) => pop(t, a) * clamp(t, b - 0.2, b, 1, 0);
export const lerp = (a: number, b: number, u: number) => a + (b - a) * u;
export const ease = (u: number) => u * u * (3 - 2 * u);
/** global seconds for a scene that starts at S */
export const useT = (S: number) => useCurrentFrame() / FPS + S;
